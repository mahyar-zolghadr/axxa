const Sequelize = require('sequelize');
const BookingContiners = sequelize.define('BookingContiners', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    ContinerNO: {
      type: Sequelize.STRING
    },
    Size: {
      type: Sequelize.INTEGER
    },
    Type: {
      type: Sequelize.STRING
    },
    FE: {
      type: Sequelize.STRING
    },
    VGM: {
      type: Sequelize.FLOAT
    },
    SealNO: {
      type: Sequelize.INTEGER
    },
    Terminal: {
      type: Sequelize.STRING
    },
    DG: {
      type: Sequelize.BOOLEAN
    },
    UN: {
      type: Sequelize.INTEGER
    },
    IMCO: {
      type: Sequelize.FLOAT
    },
    OOG: {
      type: Sequelize.BOOLEAN
    },
    OverTheLeft: {
      type: Sequelize.FLOAT
    },
    OverTheRight: {
      type: Sequelize.FLOAT
    },
    OverTheTop: {
      type: Sequelize.FLOAT
    },
    RF: {
      type: Sequelize.BOOLEAN
    },
    Temp: {
      type: Sequelize.FLOAT
    },
    Terms: {
      type: Sequelize.STRING
    },
    POD: {
      type: Sequelize.STRING
    },
    Wet: {
      type: Sequelize.BOOLEAN
    },
    Flexi: {
      type: Sequelize.BOOLEAN
    },
    TEU: {
      type: Sequelize.INTEGER
    }
  });