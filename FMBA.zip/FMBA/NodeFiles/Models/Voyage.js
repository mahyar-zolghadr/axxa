const Sequelize = require('sequelize');
const Voyage = Sequelize.define('Voyage', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    VesselId: {
      type: Sequelize.INTEGER
    },
    VoyageName: {
      type: Sequelize.INTEGER
    },
    PortId: {
      type: Sequelize.INTEGER
    },
    ArrivalAnchorage: {
      type: Sequelize.DATE
    },
    HeaveUpAnchorage: {
      type: Sequelize.DATE
    },
    PODBerthing: {
      type: Sequelize.DATE
    },
    CommenceDischarge: {
      type: Sequelize.DATE
    },
    CompleteDischarge: {
      type: Sequelize.DATE
    },
    CommenceLoading: {
      type: Sequelize.DATE
    },
    CompleteLoading: {
      type: Sequelize.DATE
    },
    POBUnBerthing: {
      type: Sequelize.DATE
    },
    Berth: {
      type: Sequelize.DATE
    },
    UnBerth: {
      type: Sequelize.DATE
    },
    PilotAwayBerthing: {
      type: Sequelize.DATE
    },
    PilotAwayUnBerthing: {
      type: Sequelize.DATE
    },
    Sailed: {
      type: Sequelize.DATE
    },
    ETANextPort: {
      type: Sequelize.DATE
    }
  });