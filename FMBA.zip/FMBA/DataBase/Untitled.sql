CREATE TABLE `BookingContiners` (
  `id` int PRIMARY KEY NOT NULL,
  `ContinerNO` text NOT NULL,
  `Size` int NOT NULL,
  `Type` text NOT NULL,
  `FE` text NOT NULL,
  `VGM` float NOT NULL,
  `SealNO` int NOT NULL,
  `Terminal` text NOT NULL,
  `DG` tinyint(1) NOT NULL,
  `UN` int NOT NULL,
  `IMCO` float NOT NULL,
  `OOG` tinyint(1) NOT NULL,
  `OverTheLeft` float NOT NULL,
  `OverTheRight` float NOT NULL,
  `OverTheTop` float NOT NULL,
  `RF` tinyint(1) NOT NULL,
  `Temp` float NOT NULL,
  `Terms` text NOT NULL,
  `POD` text NOT NULL,
  `Wet` tinyint(1) NOT NULL,
  `Flexi` tinyint(1) NOT NULL,
  `TEU` int NOT NULL
);

CREATE TABLE `BookingHeaders` (
  `id` int PRIMARY KEY NOT NULL,
  `Client` text NOT NULL,
  `POLCode` text NOT NULL,
  `FullPOL` text NOT NULL,
  `OrderDare` date NOT NULL,
  `POLAgent` text NOT NULL,
  `PODAgent` text NOT NULL,
  `Line` text NOT NULL,
  `Payer` text NOT NULL,
  `Remark` text NOT NULL
);

CREATE TABLE `BookingOrders` (
  `id` int PRIMARY KEY NOT NULL,
  `ChargesCode` text NOT NULL,
  `Size` int NOT NULL,
  `Type` text NOT NULL,
  `TotalUnit` int NOT NULL,
  `FE` tinyint(1) NOT NULL,
  `DG` tinyint(1) NOT NULL,
  `OOG` tinyint(1) NOT NULL,
  `RF` tinyint(1) NOT NULL,
  `POD` text NOT NULL,
  `Terms` text NOT NULL,
  `Terminal` text NOT NULL,
  `Currency` text NOT NULL,
  `Rate` int NOT NULL,
  `Wet` tinyint(1) NOT NULL,
  `Flexi` tinyint(1) NOT NULL,
  `TotalTEU` int NOT NULL
);

CREATE TABLE `Customer` (
  `id` int PRIMARY KEY NOT NULL,
  `CustomerName` text NOT NULL,
  `CustomerAddress` text,
  `CustomerEmail` text NOT NULL,
  `CustomerTel` text,
  `CustomerFax` text,
  `CustomerCountry` text,
  `CustomerComment` text,
  `CustomerType` varchar(50) NOT NULL
);

CREATE TABLE `FactCodeGroup` (
  `id` int PRIMARY KEY NOT NULL,
  `GroupName` int NOT NULL
);

CREATE TABLE `FactCodes` (
  `id` int PRIMARY KEY NOT NULL,
  `Code` text NOT NULL,
  `Name` text NOT NULL,
  `MeaningName` text NOT NULL,
  `GroupId` int NOT NULL
);

CREATE TABLE `FP` (
  `id` int PRIMARY KEY NOT NULL,
  `FPNumber` int NOT NULL,
  `ConfirmDate` date NOT NULL,
  `ClientId` int NOT NULL,
  `ClientName` text NOT NULL,
  `StartDate` date NOT NULL,
  `ExpireDate` date NOT NULL,
  `TLC` text NOT NULL,
  `FLC` text NOT NULL,
  `TEC` text NOT NULL,
  `FEC` text NOT NULL,
  `DGTLCL` text NOT NULL,
  `DGFLCL` text NOT NULL,
  `DGTECL` text NOT NULL,
  `DGFECL` text NOT NULL,
  `DGTLCH` text NOT NULL,
  `DGFLCH` text NOT NULL,
  `DGTECH` text NOT NULL,
  `DGFECH` text NOT NULL,
  `FlexiTL` text NOT NULL,
  `FlexiFL` text NOT NULL,
  `FlexiTE` text NOT NULL,
  `FlexiFE` text NOT NULL,
  `WetTL` text NOT NULL,
  `WetFL` text NOT NULL,
  `WetTE` text NOT NULL,
  `WetFE` text NOT NULL,
  `StackTL` text NOT NULL,
  `StackFL` text NOT NULL,
  `StackTE` text NOT NULL,
  `StackFE` text NOT NULL,
  `POD` text NOT NULL,
  `POL` text NOT NULL
);

CREATE TABLE `Port` (
  `id` int PRIMARY KEY NOT NULL,
  `PortCode` varchar(5) NOT NULL,
  `PortName` text NOT NULL,
  `PortCountry` text
);

CREATE TABLE `User` (
  `id` int PRIMARY KEY NOT NULL,
  `Username` text NOT NULL,
  `Password` text NOT NULL,
  `FullName` text NOT NULL,
  `Mail` text NOT NULL,
  `PhoneNumber` text,
  `ImagePath` text,
  `BookingDate` tinyint(1) NOT NULL,
  `BookingDateEdit` tinyint(1) NOT NULL,
  `BookingReport` tinyint(1) NOT NULL,
  `Invoice` tinyint(1) NOT NULL,
  `InvoiceEdit` tinyint(1) NOT NULL,
  `Cost` tinyint(1) NOT NULL,
  `CostEdit` tinyint(1) NOT NULL,
  `GeneralReport` tinyint(1) NOT NULL,
  `Vessel` tinyint(1) NOT NULL,
  `Voyage` tinyint(1) NOT NULL,
  `VoyageEdit` tinyint(1) NOT NULL,
  `Port` tinyint(1) NOT NULL,
  `PortEdit` tinyint(1) NOT NULL,
  `Clients` tinyint(1) NOT NULL
);

CREATE TABLE `Vessel` (
  `id` int PRIMARY KEY NOT NULL,
  `Vesselname` text NOT NULL,
  `Capacity` double DEFAULT null,
  `DeadWeight` int DEFAULT null,
  `NETWeight` int DEFAULT null,
  `BuiltDate` date DEFAULT null,
  `TEU` int DEFAULT null,
  `Speed` int DEFAULT null,
  `FeulConsumption` double DEFAULT null,
  `BlowDeckCapacity` int DEFAULT null
);

CREATE TABLE `Voyage` (
  `id` int PRIMARY KEY NOT NULL,
  `VesselId` int NOT NULL,
  `VoyageName` int NOT NULL,
  `PortId` int NOT NULL,
  `ArrivalAnchorage` date DEFAULT null,
  `HeaveUpAnchorage` date DEFAULT null,
  `PODBerthing` date DEFAULT null,
  `CommenceDischarge` date DEFAULT null,
  `CompleteDischarge` date DEFAULT null,
  `CommenceLoading` date DEFAULT null,
  `CompleteLoading` date DEFAULT null,
  `POBUnBerthing` date DEFAULT null,
  `Berth` date DEFAULT null,
  `UnBerth` date DEFAULT null,
  `PilotAwayBerthing` date DEFAULT null,
  `PilotAwayUnBerthing` date DEFAULT null,
  `Sailed` date DEFAULT null,
  `ETANextPort` date DEFAULT null
);

ALTER TABLE `Voyage` ADD FOREIGN KEY (`PortId`) REFERENCES `Port` (`id`);

ALTER TABLE `Voyage` ADD FOREIGN KEY (`VesselId`) REFERENCES `Vessel` (`id`);

ALTER TABLE `FP` ADD FOREIGN KEY (`ClientId`) REFERENCES `Customer` (`id`);
