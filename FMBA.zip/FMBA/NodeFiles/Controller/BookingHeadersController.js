const { BookingHeaders } = require('../Models/BookingHeaders.js');

const createBookingHeaders = async (client, POLCode, fullPOL, orderDare, POLAgent, PODAgent, line, payer, remark) => {
  const bookingHeaders = await BookingHeaders.create({
    Client: client,
    POLCode: POLCode,
    FullPOL: fullPOL,
    OrderDare: orderDare,
    POLAgent: POLAgent,
    PODAgent: PODAgent,
    Line: line,
    Payer: payer,
    Remark: remark,
  });

  return bookingHeaders;
};

const readBookingHeaders = async (client, POLCode, fullPOL) => {
  let query = {};

  if (client) {
    query.Client = client;
  }

  if (POLCode) {
    query.POLCode = POLCode;
  }

  if (fullPOL) {
    query.FullPOL = fullPOL;
  }

  const bookingHeaders = await BookingHeaders.findOne({
    where: query,
  });

  return bookingHeaders;
};

const updateBookingHeaders = async (client, POLCode, fullPOL, data) => {
  let query = {};

  if (client) {
    query.Client = client;
  }

  if (POLCode) {
    query.POLCode = POLCode;
  }

  if (fullPOL) {
    query.FullPOL = fullPOL;
  }

  const bookingHeaders = await BookingHeaders.findOne({
    where: query,
  });

  if (bookingHeaders) {
    const updatedBookingHeaders = await bookingHeaders.update(data);

    return updatedBookingHeaders;
  } else {
    return null;
  }
};

const deleteBookingHeaders = async (client, POLCode, fullPOL) => {
  let query = {};

  if (client) {
    query.Client = client;
  }

  if (POLCode) {
    query.POLCode = POLCode;
  }

  if (fullPOL) {
    query.FullPOL = fullPOL;
  }

  const bookingHeaders = await BookingHeaders.destroy({
    where: query,
  });

  return bookingHeaders;
};
