-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 27, 2024 at 11:25 AM
-- Server version: 8.0.39-0ubuntu0.24.04.2
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `FMBA`
--

-- --------------------------------------------------------

--
-- Table structure for table `BookingContiners`
--

CREATE TABLE `BookingContiners` (
  `id` int NOT NULL,
  `ContinerNO` text NOT NULL,
  `Size` int NOT NULL,
  `Type` text NOT NULL,
  `FE` text NOT NULL,
  `VGM` float NOT NULL,
  `SealNO` int NOT NULL,
  `Terminal` text NOT NULL,
  `DG` tinyint(1) NOT NULL,
  `UN` int NOT NULL,
  `IMCO` float NOT NULL,
  `OOG` tinyint(1) NOT NULL,
  `OverTheLeft` float NOT NULL,
  `OverTheRight` float NOT NULL,
  `OverTheTop` float NOT NULL,
  `RF` tinyint(1) NOT NULL,
  `Temp` float NOT NULL,
  `Terms` text NOT NULL,
  `POD` text NOT NULL,
  `Wet` tinyint(1) NOT NULL,
  `Flexi` tinyint(1) NOT NULL,
  `TEU` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BookingHeaders`
--

CREATE TABLE `BookingHeaders` (
  `id` int NOT NULL,
  `Client` text NOT NULL,
  `POLCode` text NOT NULL,
  `FullPOL` text NOT NULL,
  `OrderDare` date NOT NULL,
  `POLAgent` text NOT NULL,
  `PODAgent` text NOT NULL,
  `Line` text NOT NULL,
  `Payer` text NOT NULL,
  `Remark` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BookingOrders`
--

CREATE TABLE `BookingOrders` (
  `id` int NOT NULL,
  `ChargesCode` text NOT NULL,
  `Size` int NOT NULL,
  `Type` text NOT NULL,
  `TotalUnit` int NOT NULL,
  `FE` tinyint(1) NOT NULL,
  `DG` tinyint(1) NOT NULL,
  `OOG` tinyint(1) NOT NULL,
  `RF` tinyint(1) NOT NULL,
  `POD` text NOT NULL,
  `Terms` text NOT NULL,
  `Terminal` text NOT NULL,
  `Currency` text NOT NULL,
  `Rate` int NOT NULL,
  `Wet` tinyint(1) NOT NULL,
  `Flexi` tinyint(1) NOT NULL,
  `TotalTEU` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE `Customer` (
  `id` int NOT NULL,
  `CustomerName` text NOT NULL,
  `CustomerAddress` text,
  `CustomerEmail` text NOT NULL,
  `CustomerTel` text,
  `CustomerFax` text,
  `CustomerCountry` text,
  `CustomerComment` text,
  `CustomerType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FactCodeGroup`
--

CREATE TABLE `FactCodeGroup` (
  `id` int NOT NULL,
  `GroupName` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FactCodes`
--

CREATE TABLE `FactCodes` (
  `id` int NOT NULL,
  `Code` text NOT NULL,
  `Name` text NOT NULL,
  `MeaningName` text NOT NULL,
  `GroupId` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `FP`
--

CREATE TABLE `FP` (
  `id` int NOT NULL,
  `FPNumber` int NOT NULL,
  `ConfirmDate` date NOT NULL,
  `ClientId` int NOT NULL,
  `ClientName` text NOT NULL,
  `StartDate` date NOT NULL,
  `ExpireDate` date NOT NULL,
  `TLC` text NOT NULL,
  `FLC` text NOT NULL,
  `TEC` text NOT NULL,
  `FEC` text NOT NULL,
  `DGTLCL` text NOT NULL,
  `DGFLCL` text NOT NULL,
  `DGTECL` text NOT NULL,
  `DGFECL` text NOT NULL,
  `DGTLCH` text NOT NULL,
  `DGFLCH` text NOT NULL,
  `DGTECH` text NOT NULL,
  `DGFECH` text NOT NULL,
  `FlexiTL` text NOT NULL,
  `FlexiFL` text NOT NULL,
  `FlexiTE` text NOT NULL,
  `FlexiFE` text NOT NULL,
  `WetTL` text NOT NULL,
  `WetFL` text NOT NULL,
  `WetTE` text NOT NULL,
  `WetFE` text NOT NULL,
  `StackTL` text NOT NULL,
  `StackFL` text NOT NULL,
  `StackTE` text NOT NULL,
  `StackFE` text NOT NULL,
  `POD` text NOT NULL,
  `POL` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Port`
--

CREATE TABLE `Port` (
  `id` int NOT NULL,
  `PortCode` varchar(5) NOT NULL,
  `PortName` text NOT NULL,
  `PortCountry` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `User`
--

CREATE TABLE `User` (
  `id` int NOT NULL,
  `Username` text NOT NULL,
  `Password` text NOT NULL,
  `FullName` text NOT NULL,
  `Mail` text NOT NULL,
  `PhoneNumber` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ImagePath` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `BookingDate` tinyint(1) NOT NULL,
  `BookingDateEdit` tinyint(1) NOT NULL,
  `BookingReport` tinyint(1) NOT NULL,
  `Invoice` tinyint(1) NOT NULL,
  `InvoiceEdit` tinyint(1) NOT NULL,
  `Cost` tinyint(1) NOT NULL,
  `CostEdit` tinyint(1) NOT NULL,
  `GeneralReport` tinyint(1) NOT NULL,
  `Vessel` tinyint(1) NOT NULL,
  `Voyage` tinyint(1) NOT NULL,
  `VoyageEdit` tinyint(1) NOT NULL,
  `Port` tinyint(1) NOT NULL,
  `PortEdit` tinyint(1) NOT NULL,
  `Clients` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Vessel`
--

CREATE TABLE `Vessel` (
  `id` int NOT NULL,
  `Vesselname` text NOT NULL,
  `Capacity` double DEFAULT NULL,
  `DeadWeight` int DEFAULT NULL,
  `NETWeight` int DEFAULT NULL,
  `BuiltDate` date DEFAULT NULL,
  `TEU` int DEFAULT NULL,
  `Speed` int DEFAULT NULL,
  `FeulConsumption` double DEFAULT NULL,
  `BlowDeckCapacity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Voyage`
--

CREATE TABLE `Voyage` (
  `id` int NOT NULL,
  `VesselId` int NOT NULL,
  `VoyageName` int NOT NULL,
  `PortId` int NOT NULL,
  `ArrivalAnchorage` date DEFAULT NULL,
  `HeaveUpAnchorage` date DEFAULT NULL,
  `PODBerthing` date DEFAULT NULL,
  `CommenceDischarge` date DEFAULT NULL,
  `CompleteDischarge` date DEFAULT NULL,
  `CommenceLoading` date DEFAULT NULL,
  `CompleteLoading` date DEFAULT NULL,
  `POBUnBerthing` date DEFAULT NULL,
  `Berth` date DEFAULT NULL,
  `UnBerth` date DEFAULT NULL,
  `PilotAwayBerthing` date DEFAULT NULL,
  `PilotAwayUnBerthing` date DEFAULT NULL,
  `Sailed` date DEFAULT NULL,
  `ETANextPort` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `BookingContiners`
--
ALTER TABLE `BookingContiners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BookingHeaders`
--
ALTER TABLE `BookingHeaders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `BookingOrders`
--
ALTER TABLE `BookingOrders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `FactCodeGroup`
--
ALTER TABLE `FactCodeGroup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `FactCodes`
--
ALTER TABLE `FactCodes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `FP`
--
ALTER TABLE `FP`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Port`
--
ALTER TABLE `Port`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Vessel`
--
ALTER TABLE `Vessel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Voyage`
--
ALTER TABLE `Voyage`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `BookingContiners`
--
ALTER TABLE `BookingContiners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BookingHeaders`
--
ALTER TABLE `BookingHeaders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BookingOrders`
--
ALTER TABLE `BookingOrders`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Customer`
--
ALTER TABLE `Customer`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `FactCodeGroup`
--
ALTER TABLE `FactCodeGroup`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `FactCodes`
--
ALTER TABLE `FactCodes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `FP`
--
ALTER TABLE `FP`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Port`
--
ALTER TABLE `Port`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `User`
--
ALTER TABLE `User`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Vessel`
--
ALTER TABLE `Vessel`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Voyage`
--
ALTER TABLE `Voyage`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
