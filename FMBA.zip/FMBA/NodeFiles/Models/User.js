const Sequelize = require('sequelize');


const sequelize = new Sequelize('FMBA', 'root', 'Mahyar!1397', {
  host: 'localhost',
  dialect: 'mysql'
});

const User = sequelize.define('User', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    Username: {
      type: Sequelize.STRING
    },
    Password: {
      type: Sequelize.STRING
    },
    FullName: {
      type: Sequelize.STRING
    },
    Mail: {
      type: Sequelize.STRING
    },
    PhoneNumber: {
      type: Sequelize.STRING
    },
    ImagePath: {
      type: Sequelize.STRING
    },
    BookingDate: {
      type: Sequelize.BOOLEAN
    },
    BookingDateEdit: {
      type: Sequelize.BOOLEAN
    },
    BookingReport: {
      type: Sequelize.BOOLEAN
    },
    Invoice: {
      type: Sequelize.BOOLEAN
    },
    InvoiceEdit: {
      type: Sequelize.BOOLEAN
    },
    Cost: {
      type: Sequelize.BOOLEAN
    },
    CostEdit: {
      type: Sequelize.BOOLEAN
    },
    GeneralReport: {
      type: Sequelize.BOOLEAN
    },
    Vessel: {
      type: Sequelize.BOOLEAN
    },
    Voyage: {
      type: Sequelize.BOOLEAN
    },
    VoyageEdit: {
      type: Sequelize.BOOLEAN
    },
    Port: {
      type: Sequelize.BOOLEAN
    },
    PortEdit: {
      type: Sequelize.BOOLEAN
    },
    Clients: {
      type: Sequelize.BOOLEAN
    }
  },{
    tableName: 'User',
    // freezeTableName: true,
    timestamps: false,
  });

  module.exports = {User, sequelize};

