const { Customer } = require('../Models/Customer.js');

const createCustomer = async (customerName, customerAddress, customerEmail, customerTel, customerFax, customerCountry, customerComment, customerType) => {
  const customer = await Customer.create({
    CustomerName: customerName,
    CustomerAddress: customerAddress,
    CustomerEmail: customerEmail,
    CustomerTel: customerTel,
    CustomerFax: customerFax,
    CustomerCountry: customerCountry,
    CustomerComment: customerComment,
    CustomerType: customerType,
  });

  return customer;
};

const readCustomer = async (customerName, customerEmail) => {
  let query = {};

  if (customerName) {
    query.CustomerName = customerName;
  }

  if (customerEmail) {
    query.CustomerEmail = customerEmail;
  }

  const customer = await Customer.findOne({
    where: query,
  });

  return customer;
};

const updateCustomer = async (customerName, customerEmail, data) => {
  let query = {};

  if (customerName) {
    query.CustomerName = customerName;
  }

  if (customerEmail) {
    query.CustomerEmail = customerEmail;
  }

  const customer = await Customer.findOne({
    where: query,
  });

  if (customer) {
    const updatedCustomer = await customer.update(data);

    return updatedCustomer;
  } else {
    return null;
  }
};

const deleteCustomer = async (customerName, customerEmail) => {
  let query = {};

  if (customerName) {
    query.CustomerName = customerName;
  }

  if (customerEmail) {
    query.CustomerEmail = customerEmail;
  }

  const customer = await Customer.destroy({
    where: query,
  });

  return customer;
};