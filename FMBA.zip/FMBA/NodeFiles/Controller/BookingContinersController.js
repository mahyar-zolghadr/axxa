const { BookingContiners } = require('../Models/BookingContiners.js');

const createBookingContiners = async (continerNO, size, type, FE, VGM, sealNO, terminal, DG, UN, IMCO, OOG, overTheLeft, overTheRight, overTheTop, RF, temp, terms, POD, wet, flexi, TEU) => {
  const bookingContiners = await BookingContiners.create({
    ContinerNO: continerNO,
    Size: size,
    Type: type,
    FE: FE,
    VGM: VGM,
    SealNO: sealNO,
    Terminal: terminal,
    DG: DG,
    UN: UN,
    IMCO: IMCO,
    OOG: OOG,
    OverTheLeft: overTheLeft,
    OverTheRight: overTheRight,
    OverTheTop: overTheTop,
    RF: RF,
    Temp: temp,
    Terms: terms,
    POD: POD,
    Wet: wet,
    Flexi: flexi,
    TEU: TEU,
  });

  return bookingContiners;
};

const readBookingContiners = async (continerNO, size, type, FE) => {
  let query = {};

  if (continerNO) {
    query.ContinerNO = continerNO;
  }

  if (size) {
    query.Size = size;
  }

  if (type) {
    query.Type = type;
  }

  if (FE) {
    query.FE = FE;
  }

  const bookingContiners = await BookingContiners.findOne({
    where: query,
  });

  return bookingContiners;
};

const updateBookingContiners = async (continerNO, size, type, FE, data) => {
  let query = {};

  if (continerNO) {
    query.ContinerNO = continerNO;
  }

  if (size) {
    query.Size = size;
  }

  if (type) {
    query.Type = type;
  }

  if (FE) {
    query.FE = FE;
  }

  const bookingContiners = await BookingContiners.findOne({
    where: query,
  });

  if (bookingContiners) {
    const updatedBookingContiners = await bookingContiners.update(data);

    return updatedBookingContiners;
  } else {
    return null;
  }
};

const deleteBookingContiners = async (continerNO, size, type, FE) => {
  let query = {};

  if (continerNO) {
    query.ContinerNO = continerNO;
  }

  if (size) {
    query.Size = size;
  }

  if (type) {
    query.Type = type;
  }

  if (FE) {
    query.FE = FE;
  }

  const bookingContiners = await BookingContiners.destroy({
    where: query,
  });

  return bookingContiners;
};
