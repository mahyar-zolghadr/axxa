const { BookingOrders } = require('../Models/BookingOrders.js');

const createBookingOrders = async (chargesCode, size, type, totalUnit, FE, DG, OOG, RF, POD, terms, terminal, currency, rate, wet, flexi, totalTEU) => {
  const bookingOrders = await BookingOrders.create({
    ChargesCode: chargesCode,
    Size: size,
    Type: type,
    TotalUnit: totalUnit,
    FE: FE,
    DG: DG,
    OOG: OOG,
    RF: RF,
    POD: POD,
    Terms: terms,
    Terminal: terminal,
    Currency: currency,
    Rate: rate,
    Wet: wet,
    Flexi: flexi,
    TotalTEU: totalTEU,
  });

  return bookingOrders;
};

const readBookingOrders = async (chargesCode, size, type) => {
  let query = {};

  if (chargesCode) {
    query.ChargesCode = chargesCode;
  }

  if (size) {
    query.Size = size;
  }

  if (type) {
    query.Type = type;
  }

  const bookingOrders = await BookingOrders.findOne({
    where: query,
  });

  return bookingOrders;
};

const updateBookingOrders = async (chargesCode, size, type, data) => {
  let query = {};

  if (chargesCode) {
    query.ChargesCode = chargesCode;
  }

  if (size) {
    query.Size = size;
  }

  if (type) {
    query.Type = type;
  }

  const bookingOrders = await BookingOrders.findOne({
    where: query,
  });

  if (bookingOrders) {
    const updatedBookingOrders = await bookingOrders.update(data);

    return updatedBookingOrders;
  } else {
    return null;
  }
};

const deleteBookingOrders = async (chargesCode, size, type) => {
  let query = {};

  if (chargesCode) {
    query.ChargesCode = chargesCode;
  }

  if (size) {
    query.Size = size;
  }

  if (type) {
    query.Type = type;
  }

  const bookingOrders = await BookingOrders.destroy({
    where: query,
  });

  return bookingOrders;
};