const Sequelize = require('sequelize');
const FactCodeGroup = sequelize.define('FactCodeGroup', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    GroupName: {
      type: Sequelize.INTEGER
    }
  });