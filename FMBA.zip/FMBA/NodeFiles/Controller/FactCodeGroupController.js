const { FactCodeGroup } = require('../Models/FactCodeGroup.js');

const createFactCodeGroup = async (groupName) => {
  const factCodeGroup = await FactCodeGroup.create({
    GroupName: groupName,
  });

  return factCodeGroup;
};

const readFactCodeGroup = async (groupName) => {
  let query = {};

  if (groupName) {
    query.GroupName = groupName;
  }

  const factCodeGroup = await FactCodeGroup.findOne({
    where: query,
  });

  return factCodeGroup;
};

const updateFactCodeGroup = async (groupName, data) => {
  let query = {};

  if (groupName) {
    query.GroupName = groupName;
  }

  const factCodeGroup = await FactCodeGroup.findOne({
    where: query,
  });

  if (factCodeGroup) {
    const updatedFactCodeGroup = await factCodeGroup.update(data);

    return updatedFactCodeGroup;
  } else {
    return null;
  }
};

const deleteFactCodeGroup = async (groupName) => {
  let query = {};

  if (groupName) {
    query.GroupName = groupName;
  }

  const factCodeGroup = await FactCodeGroup.destroy({
    where: query,
  });

  return factCodeGroup;
};