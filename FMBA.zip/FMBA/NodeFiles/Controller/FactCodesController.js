const { FactCodes } = require('../Models/FactCodes.js');

const createFactCodes = async (code, name, meaningName, groupId) => {
  const factCodes = await FactCodes.create({
    Code: code,
    Name: name,
    MeaningName: meaningName,
    GroupId: groupId,
  });

  return factCodes;
};

const readFactCodes = async (code, name) => {
  let query = {};

  if (code) {
    query.Code = code;
  }

  if (name) {
    query.Name = name;
  }

  const factCodes = await FactCodes.findOne({
    where: query,
  });

  return factCodes;
};

const updateFactCodes = async (code, name, data) => {
  let query = {};

  if (code) {
    query.Code = code;
  }

  if (name) {
    query.Name = name;
  }

  const factCodes = await FactCodes.findOne({
    where: query,
  });

  if (factCodes) {
    const updatedFactCodes = await factCodes.update(data);

    return updatedFactCodes;
  } else {
    return null;
  }
};

const deleteFactCodes = async (code, name) => {
  let query = {};

  if (code) {
    query.Code = code;
  }

  if (name) {
    query.Name = name;
  }

  const factCodes = await FactCodes.destroy({
    where: query,
  });

  return factCodes;
};