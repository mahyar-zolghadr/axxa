const { Vessel } = require('../Models/Vessel.js');

const createVessel = async (vesselname, capacity, deadWeight, NETWeight, builtDate, TEU, speed, feulConsumption, blowDeckCapacity) => {
  const vessel = await Vessel.create({
    Vesselname: vesselname,
    Capacity: capacity,
    DeadWeight: deadWeight,
    NETWeight: NETWeight,
    BuiltDate: builtDate,
    TEU: TEU,
    Speed: speed,
    FeulConsumption: feulConsumption,
    BlowDeckCapacity: blowDeckCapacity,
  });

  return vessel;
};

const readVessel = async (vesselname, capacity) => {
  let query = {};

  if (vesselname) {
    query.Vesselname = vesselname;
  }

  if (capacity) {
    query.Capacity = capacity;
  }

  const vessel = await Vessel.findOne({
    where: query,
  });

  return vessel;
};

const updateVessel = async (vesselname, capacity, data) => {
  let query = {};

  if (vesselname) {
    query.Vesselname = vesselname;
  }

  if (capacity) {
    query.Capacity = capacity;
  }

  const vessel = await Vessel.findOne({
    where: query,
  });

  if (vessel) {
    const updatedVessel = await vessel.update(data);

    return updatedVessel;
  } else {
    return null;
  }
};

const deleteVessel = async (vesselname, capacity) => {
  let query = {};

  if (vesselname) {
    query.Vesselname = vesselname;
  }

  if (capacity) {
    query.Capacity = capacity;
  }

  const vessel = await Vessel.destroy({
    where: query,
  });

  return vessel;
};