const Sequelize = require('sequelize');
const Customer = sequelize.define('Customer', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    CustomerName: {
      type: Sequelize.STRING
    },
    CustomerAddress: {
      type: Sequelize.STRING
    },
    CustomerEmail: {
      type: Sequelize.STRING
    },
    CustomerTel: {
      type: Sequelize.STRING
    },
    CustomerFax: {
      type: Sequelize.STRING
    },
    CustomerCountry: {
      type: Sequelize.STRING
    },
    CustomerComment: {
      type: Sequelize.STRING
    },
    CustomerType: {
      type: Sequelize.STRING
    }
  });