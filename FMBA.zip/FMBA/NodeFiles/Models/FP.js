const Sequelize = require('sequelize');
const FP = sequelize.define('FP', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    FPNumber: {
      type: Sequelize.INTEGER
    },
    ConfirmDate: {
      type: Sequelize.DATE
    },
    ClientId: {
      type: Sequelize.INTEGER
    },
    ClientName: {
      type: Sequelize.STRING
    },
    StartDate: {
      type: Sequelize.DATE
    },
    ExpireDate: {
      type: Sequelize.DATE
    },
    TLC: {
      type: Sequelize.STRING
    },
    FLC: {
      type: Sequelize.STRING
    },
    TEC: {
      type: Sequelize.STRING
    },
    FEC: {
      type: Sequelize.STRING
    },
    DGTLCL: {
      type: Sequelize.STRING
    },
    DGFLCL: {
      type: Sequelize.STRING
    },
    DGTECL: {
      type: Sequelize.STRING
    },
    DGFECL: {
      type: Sequelize.STRING
    },
    DGTLCH: {
      type: Sequelize.STRING
    },
    DGFLCH: {
      type: Sequelize.STRING
    },
    DGTECH: {
      type: Sequelize.STRING
    },
    DGFECH: {
      type: Sequelize.STRING
    },
    FlexiTL: {
      type: Sequelize.STRING
    },
    FlexiFL: {
      type: Sequelize.STRING
    },
    FlexiTE: {
      type: Sequelize.STRING
    },
    FlexiFE: {
      type: Sequelize.STRING
    },
    WetTL: {
      type: Sequelize.STRING
    },
    WetFL: {
      type: Sequelize.STRING
    },
    WetTE: {
      type: Sequelize.STRING
    },
    WetFE: {
      type: Sequelize.STRING
    },
    StackTL: {
      type: Sequelize.STRING
    },
    StackFL: {
      type: Sequelize.STRING
    },
    StackTE: {
      type: Sequelize.STRING
    },
    StackFE: {
      type: Sequelize.STRING
    },
    POD: {
      type: Sequelize.STRING
    },
    POL: {
      type: Sequelize.STRING
    }
  });