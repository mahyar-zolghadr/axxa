const Sequelize = require('sequelize');
const FactCodes = sequelize.define('FactCodes', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    Code: {
      type: Sequelize.STRING
    },
    Name: {
      type: Sequelize.STRING
    },
    MeaningName: {
      type: Sequelize.STRING
    },
    GroupId: {
      type: Sequelize.INTEGER
    }
  });