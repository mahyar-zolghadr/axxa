const { Port } = require('../Models/Port.js');

const createPort = async (portCode, portName, portCountry) => {
  const port = await Port.create({
    PortCode: portCode,
    PortName: portName,
    PortCountry: portCountry,
  });

  return port;
};

const readPort = async (portCode, portName) => {
  let query = {};

  if (portCode) {
    query.PortCode = portCode;
  }

  if (portName) {
    query.PortName = portName;
  }

  const port = await Port.findOne({
    where: query,
  });

  return port;
};

const updatePort = async (portCode, portName, data) => {
  let query = {};

  if (portCode) {
    query.PortCode = portCode;
  }

  if (portName) {
    query.PortName = portName;
  }

  const port = await Port.findOne({
    where: query,
  });

  if (port) {
    const updatedPort = await port.update(data);

    return updatedPort;
  } else {
    return null;
  }
};

const deletePort = async (portCode, portName) => {
  let query = {};

  if (portCode) {
    query.PortCode = portCode;
  }

  if (portName) {
    query.PortName = portName;
  }

  const port = await Port.destroy({
    where: query,
  });

  return port;
};