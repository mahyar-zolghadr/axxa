const Sequelize = require('sequelize');
const Vessel = sequelize.define('Vessel', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    Vesselname: {
      type: Sequelize.STRING
    },
    Capacity: {
      type: Sequelize.DOUBLE
    },
    DeadWeight: {
      type: Sequelize.INTEGER
    },
    NETWeight: {
      type: Sequelize.INTEGER
    },
    BuiltDate: {
      type: Sequelize.DATE
    },
    TEU: {
      type: Sequelize.INTEGER
    },
    Speed: {
      type: Sequelize.INTEGER
    },
    FeulConsumption: {
      type: Sequelize.DOUBLE
    },
    BlowDeckCapacity: {
      type: Sequelize.INTEGER
    }
  });