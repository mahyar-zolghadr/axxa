const { User } = require('../Models/User.js');

const createUser = async (username, password, fullName, mail, phoneNumber, imagePath, bookingDate, bookingDateEdit, bookingReport, invoice, invoiceEdit, cost, costEdit, generalReport, vessel, voyage, voyageEdit, port, portEdit, clients) => {
  const user = await User.create({
    Username: username,
    Password: password,
    FullName: fullName,
    Mail: mail,
    PhoneNumber: phoneNumber,
    ImagePath: imagePath,
    BookingDate: bookingDate,
    BookingDateEdit: bookingDateEdit,
    BookingReport: bookingReport,
    Invoice: invoice,
    InvoiceEdit: invoiceEdit,
    Cost: cost,
    CostEdit: costEdit,
    GeneralReport: generalReport,
    Vessel: vessel,
    Voyage: voyage,
    VoyageEdit: voyageEdit,
    Port: port,
    PortEdit: portEdit,
    Clients: clients,
  });

  return user;
};

const readUser  = async (username, mail, phoneNumber, fullName) => {
  let query = {};

  if (username) {
    query.Username = username;
  }

  if (mail) {
    query.Mail = mail;
  }

  if (phoneNumber) {
    query.PhoneNumber = phoneNumber;
  }

  if (fullName) {
    query.FullName = fullName;
  }

  const user = await User.findOne({
    where: query,
  });

  return user;
};

const updateUser = async (username, mail, phoneNumber, fullName, data) => {
  let query = {};

  if (username) {
    query.Username = username;
  }

  if (mail) {
    query.Mail = mail;
  }

  if (phoneNumber) {
    query.PhoneNumber = phoneNumber;
  }

  if (fullName) {
    query.FullName = fullName;
  }

  const user = await User.findOne({
    where: query,
  });

  if (user) {
    const updatedUser  = await user.update(data);

    return updatedUser ;
  } else {
    return null;
  }
};

const deleteUser = async (username, mail, phoneNumber, fullName) => {
  let query = {};

  if (username) {
    query.Username = username;
  }

  if (mail) {
    query.Mail = mail;
  }

  if (phoneNumber) {
    query.PhoneNumber = phoneNumber;
  }

  if (fullName) {
    query.FullName = fullName;
  }

  const user = await User.destroy({
    where: query,
  });

  return user;
};