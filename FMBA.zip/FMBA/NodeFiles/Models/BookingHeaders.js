const Sequelize = require('sequelize');
const BookingHeaders = sequelize.define('BookingHeaders', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    Client: {
      type: Sequelize.STRING
    },
    POLCode: {
      type: Sequelize.STRING
    },
    FullPOL: {
      type: Sequelize.STRING
    },
    OrderDare: {
      type: Sequelize.DATE
    },
    POLAgent: {
      type: Sequelize.STRING
    },
    PODAgent: {
      type: Sequelize.STRING
    },
    Line: {
      type: Sequelize.STRING
    },
    Payer: {
      type: Sequelize.STRING
    },
    Remark: {
      type: Sequelize.STRING
    }
  });