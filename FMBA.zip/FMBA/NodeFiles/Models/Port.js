const Sequelize = require('sequelize');
const Port = sequelize.define('Port', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    PortCode: {
      type: Sequelize.STRING
    },
    PortName: {
      type: Sequelize.STRING
    },
    PortCountry: {
      type: Sequelize.STRING
    }
  });