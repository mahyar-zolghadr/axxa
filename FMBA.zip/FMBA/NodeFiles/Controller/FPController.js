const { FP } = require('../Models/FP.js');

const createFP = async (FPNumber, confirmDate, clientId, clientName, startDate, expireDate, TLC, FLC, TEC, FEC, DGTLCL, DGFLCL, DGTECL, DGFECL, DGTLCH, DGFLCH, DGTECH, DGFECH, FlexiTL, FlexiFL, FlexiTE, FlexiFE, WetTL, WetFL, WetTE, WetFE, StackTL, StackFL, StackTE, StackFE, POD, POL) => {
  const fp = await FP.create({
    FPNumber: FPNumber,
    ConfirmDate: confirmDate,
    ClientId: clientId,
    ClientName: clientName,
    StartDate: startDate,
    ExpireDate: expireDate,
    TLC: TLC,
    FLC: FLC,
    TEC: TEC,
    FEC: FEC,
    DGTLCL: DGTLCL,
    DGFLCL: DGFLCL,
    DGTECL: DGTECL,
    DGFECL: DGFECL,
    DGTLCH: DGTLCH,
    DGFLCH: DGFLCH,
    DGTECH: DGTECH,
    DGFECH: DGFECH,
    FlexiTL: FlexiTL,
    FlexiFL: FlexiFL,
    FlexiTE: FlexiTE,
    FlexiFE: FlexiFE,
    WetTL: WetTL,
    WetFL: WetFL,
    WetTE: WetTE,
    WetFE: WetFE,
    StackTL: StackTL,
    StackFL: StackFL,
    StackTE: StackTE,
    StackFE: StackFE,
    POD: POD,
    POL: POL,
  });

  return fp;
};

const readFP = async (FPNumber, clientId, clientName) => {
  let query = {};

  if (FPNumber) {
    query.FPNumber = FPNumber;
  }

  if (clientId) {
    query.ClientId = clientId;
  }

  if (clientName) {
    query.ClientName = clientName;
  }

  const fp = await FP.findOne({
    where: query,
  });

  return fp;
};

const updateFP = async (FPNumber, clientId, clientName, data) => {
  let query = {};

  if (FPNumber) {
    query.FPNumber = FPNumber;
  }

  if (clientId) {
    query.ClientId = clientId;
  }

  if (clientName) {
    query.ClientName = clientName;
  }

  const fp = await FP.findOne({
    where: query,
  });

  if (fp) {
    const updatedFP = await fp.update(data);

    return updatedFP;
  } else {
    return null;
  }
};

const deleteFP = async (FPNumber, clientId, clientName) => {
  let query = {};

  if (FPNumber) {
    query.FPNumber = FPNumber;
  }

  if (clientId) {
    query.ClientId = clientId;
  }

  if (clientName) {
    query.ClientName = clientName;
  }

  const fp = await FP.destroy({
    where: query,
  });

  return fp;
};