const Sequelize = require('sequelize');
const BookingOrders = sequelize.define('BookingOrders', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    ChargesCode: {
      type: Sequelize.STRING
    },
    Size: {
      type: Sequelize.INTEGER
    },
    Type: {
      type: Sequelize.STRING
    },
    TotalUnit: {
      type: Sequelize.INTEGER
    },
    FE: {
      type: Sequelize.BOOLEAN
    },
    DG: {
      type: Sequelize.BOOLEAN
    },
    OOG: {
      type: Sequelize.BOOLEAN
    },
    RF: {
      type: Sequelize.BOOLEAN
    },
    POD: {
      type: Sequelize.STRING
    },
    Terms: {
      type: Sequelize.STRING
    },
    Terminal: {
      type: Sequelize.STRING
    },
    Currency: {
      type: Sequelize.STRING
    },
    Rate: {
      type: Sequelize.INTEGER
    },
    Wet: {
      type: Sequelize.BOOLEAN
    },
    Flexi: {
      type: Sequelize.BOOLEAN
    },
    TotalTEU: {
      type: Sequelize.INTEGER
    }
  });