// function ShowSameDate(Username='', FullName='', Mail='', PhoneNumber='') {
//     var DataTrue = [];
//     if (Username!='') {
//         DataTrue.push(Username);
//     }else if(FullName!=''){
//         DataTrue.push(FullName);
//     }else if(Mail!=''){
//         DataTrue.push(Mail);
//     }else if(PhoneNumber!=''){
//         DataTrue.push(PhoneNumber);
//     }else{
//         console.log("Nothing To Show");
//     }
//     console.log(DataTrue);
    
// };

// ShowSameDate('werd','asdddddd',);


  
  ShowSameDate('werd', 'sdfsd','sdsd', 'wwwwwwwwww', 'sddcsssss');