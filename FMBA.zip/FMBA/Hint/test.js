const express = require('express');
const app = express();

app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('index');
});

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  if (username === 'admin' && password === 'admin') {
    res.render('login-success');
  } else {
    res.render('login-fail');
  }
});

app.listen(3000, '0.0.0.0', () => {
  console.log('Server started on port 3000');
});