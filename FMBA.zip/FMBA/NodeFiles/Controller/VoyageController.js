const { Voyage } = require('../Models/Voyage.js');

const createVoyage = async (vesselId, voyageName, portId, arrivalAnchorage, heaveUpAnchorage, PODBerthing, commenceDischarge, completeDischarge, commenceLoading, completeLoading, POBUnBerthing, berth, unBerth, pilotAwayBerthing, pilotAwayUnBerthing, sailed, ETANextPort) => {
  const voyage = await Voyage.create({
    VesselId: vesselId,
    VoyageName: voyageName,
    PortId: portId,
    ArrivalAnchorage: arrivalAnchorage,
    HeaveUpAnchorage: heaveUpAnchorage,
    PODBerthing: PODBerthing,
    CommenceDischarge: commenceDischarge,
    CompleteDischarge: completeDischarge,
    CommenceLoading: commenceLoading,
    CompleteLoading: completeLoading,
    POBUnBerthing: POBUnBerthing,
    Berth: berth,
    UnBerth: unBerth,
    PilotAwayBerthing: pilotAwayBerthing,
    PilotAwayUnBerthing: pilotAwayUnBerthing,
    Sailed: sailed,
    ETANextPort: ETANextPort,
  });

  return voyage;
};

const readVoyage = async (vesselId, voyageName, portId) => {
  let query = {};

  if (vesselId) {
    query.VesselId = vesselId;
  }

  if (voyageName) {
    query.VoyageName = voyageName;
  }

  if (portId) {
    query.PortId = portId;
  }

  const voyage = await Voyage.findOne({
    where: query,
  });

  return voyage;
};

const updateVoyage = async (vesselId, voyageName, portId, data) => {
  let query = {};

  if (vesselId) {
    query.VesselId = vesselId;
  }

  if (voyageName) {
    query.VoyageName = voyageName;
  }

  if (portId) {
    query.PortId = portId;
  }

  const voyage = await Voyage.findOne({
    where: query,
  });

  if (voyage) {
    const updatedVoyage = await voyage.update(data);

    return updatedVoyage;
  } else {
    return null;
  }
};

const deleteVoyage = async (vesselId, voyageName, portId) => {
  let query = {};

  if (vesselId) {
    query.VesselId = vesselId;
  }

  if (voyageName) {
    query.VoyageName = voyageName;
  }

  if (portId) {
    query.PortId = portId;
  }

  const voyage = await Voyage.destroy({
    where: query,
  });

  return voyage;
};